%% Find Cluster
display '--Find cluster for GFCC--'
addpath(genpath('/vol/ek/dattias/PeptideDocking/bin/matlabScripts'));
pathdef;

findClosestCluster('GFCC');

display '--DONE--'
