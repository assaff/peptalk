#!/usr/bin/perl
# author: dattias
# normalizeSampleData.pl

use strict;

# $mode:
# 'learn' - create normalized training matrix
# 'names' - get feature names for normalize matrix
my $mode = $ARGV[0];

my $inputFile = $ARGV[1];
my $outputFile = $ARGV[2];

# 1  numFragmentsPerProtein
# 2  avgAtomsPerFragmentPerProtein
# 3  numExactFragmentsPerResidue
# 4  numApproxFragmentsPerResidue
# 5  numExactAtomsPerResidue
# 6  numApproxAtomsPerResidue
# 7  avgConservationPerProtein
# 8  conservationPerResidue
# 9  residueMoreConservedThanAvg
# 10 residueInPocket
# 11 residuePocketNumber
# 12 holesValuePerResidue
# 13 AA_NUM
# 14 AA_HYDROPHOBIC
# 15 AA_POLAR
# 16 AA_AROMATIC
# 17 AA_ALIPHATIC
# 18 AA_HBONDING
my %features = (
	1  => "numFragmentsPerProtein",
	2  => "avgAtomsPerFragmentPerProtein",
	3  => "numExactFragmentsPerResidue",
	4  => "numApproxFragmentsPerResidue",
	5  => "numExactAtomsPerResidue",
	6  => "numApproxAtomsPerResidue",
	7  => "avgConservationPerProtein",
	8  => "conservationPerResidue",
	9  => "residueMoreConservedThanAvg",
	10  => "residueInPocket",
	11 => "residuePocketNumber",
	12 => "holesValuePerResidue",
	13 => "AA_NUM",
	14 => "AA_HYDROPHOBIC",
	15 => "AA_POLAR",
	16 => "AA_AROMATIC",
	17 => "AA_ALIPHATIC",
	18 => "AA_HBONDING"
);

open(IN, "<$inputFile") or die $!;
open(OUT, ">$outputFile") or die $!;

my @featuresNames = ();
my $numFeature = 1;
my @finalFeatures;
my @currentFeatures;
my @names;
foreach my $line (<IN>){
	chomp($line);
	$numFeature = 1;
	@finalFeatures = ();
	
	my @features = split(/ /, $line);
	my $label = $features[0];
	
	for(my $i = 1; $i < scalar @features; $i++){
		my @parts = split(/:/, $features[$i]);
		if($parts[0] == 1){
			add_numFragmentsPerProtein($parts[1], \@currentFeatures, \@names, $parts[0]);
			@finalFeatures = (@finalFeatures, @currentFeatures);
			#print OUT "@currentFeatures\nDONE numFragmentsPerProtein\n";
		}
		elsif($parts[0] == 2){
			add_avgAtomsPerFragmentPerProtein($parts[1], \@currentFeatures, \@names, $parts[0]);
			@finalFeatures = (@finalFeatures, @currentFeatures);
			#print OUT "@currentFeatures\nDONE avgAtomsPerFragmentPerProtein\n";
		}
		elsif($parts[0] == 3){
			add_numExactFragmentsPerResidue($parts[1], \@currentFeatures, \@names, $parts[0]);
			@finalFeatures = (@finalFeatures, @currentFeatures);
			#print OUT "@currentFeatures\nDONE numExactFragmentsPerResidue\n";
		}
		elsif($parts[0] == 4){
			add_numApproxFragmentsPerResidue($parts[1], \@currentFeatures, \@names, $parts[0]);
			@finalFeatures = (@finalFeatures, @currentFeatures);
			#print OUT "@currentFeatures\nDONE numApproxFragmentsPerResidue\n";
		}
		elsif($parts[0] == 5){
			add_numExactAtomsPerResidue($parts[1], \@currentFeatures, \@names, $parts[0]);
			@finalFeatures = (@finalFeatures, @currentFeatures);
			#print OUT "@currentFeatures\nDONE numExactAtomsPerResidue\n";
		}
		elsif($parts[0] == 6){
			add_numApproxAtomsPerResidue($parts[1], \@currentFeatures, \@names, $parts[0]);
			@finalFeatures = (@finalFeatures, @currentFeatures);
			#print OUT "@currentFeatures\nDONE numApproxAtomsPerResidue\n";
		}
		elsif($parts[0] == 7){
			add_avgConservationPerProtein($parts[1], \@currentFeatures, \@names, $parts[0]);
			@finalFeatures = (@finalFeatures, @currentFeatures);
			#print OUT "@currentFeatures\nDONE avgConservationPerProtein\n";
		}
		elsif($parts[0] == 8){
			add_conservationPerResidue($parts[1], \@currentFeatures, \@names, $parts[0]);
			@finalFeatures = (@finalFeatures, @currentFeatures);
			#print OUT "@currentFeatures\nDONE conservationPerResidue\n";
		}
		elsif($parts[0] == 11){
			add_residuePocketNumber($parts[1], \@currentFeatures, \@names, $parts[0]);
			@finalFeatures = (@finalFeatures, @currentFeatures);
			#print OUT "@currentFeatures\nDONE residuePocketNumber\n";
		}
		elsif($parts[0] == 12){
			add_holesValuePerResidue($parts[1], \@currentFeatures, \@names, $parts[0]);
			@finalFeatures = (@finalFeatures, @currentFeatures);
			#print OUT "@currentFeatures\nDONE holesValuePerResidue\n";
		}
		elsif($parts[0] == 13){
			#next;
			add_aaNumber($parts[1], \@currentFeatures, \@names, $parts[0]);
			@finalFeatures = (@finalFeatures, @currentFeatures);
			#print OUT "@currentFeatures\nDONE aaNumber\n";
		}
		else{
			#if(substr($features{$parts[0]}, 0, 2) eq "AA"){
			#	next;
			#}
			@names = ($features{$parts[0]});
			@finalFeatures = (@finalFeatures, $parts[1]);
			#print OUT $parts[1]."\nDONE ".$features{$parts[0]}."\n";
		}
		
		if($mode eq 'names'){
			@featuresNames = (@featuresNames, @names);
		}
	}
	
	if($mode eq 'names'){
		numberFeatures(\@featuresNames);
		last;
	}
	numberFeatures(\@finalFeatures);
	my $featuresStr = join(' ', @finalFeatures);
	print OUT "$label $featuresStr\n";
}

if($mode eq 'names'){
	my $finalStr = join(' ', @featuresNames);
	$finalStr =~ s/ /\n/g;
	print OUT $finalStr."\n";
}
#open(FEATURES, ">$featuresFile") or die $!;
#print FEATURES join(/\n/, @featuresNames)."\n";
#close(FEATURES);

close(OUT);
close(IN);

########################################################
sub numberFeatures{
	my ($featuresList) = @_;
	
	for(my $i = 0; $i < scalar @$featuresList; $i++){
		$$featuresList[$i] = ($i+1).":".$$featuresList[$i];
	}
}

sub add_numFragmentsPerProtein{
	my($value, $myFeatures, $names, $number) = @_;
	
	if($mode eq 'learn'){
		@$myFeatures = (0, 0, 0);
		# 0: 0-5
		# 1: 6-10
		# 2: 11-..
		if($value > 0 && $value <= 5){
			$$myFeatures[0] = "1";
		}
		elsif($value > 5 && $value <= 10){
			$$myFeatures[1] = "1";
		}
		elsif($value > 10){
			$$myFeatures[2] = "1";
		}
	}
	else{
		@$names = ("", "", "");
		
		$$names[0] = $features{$number}."[0-5]";
		$$names[1] = $features{$number}."[6-10]";
		$$names[2] = $features{$number}."[>11]";
	}
}

sub add_avgAtomsPerFragmentPerProtein{
	my($value, $myFeatures, $names, $number) = @_;
	
	if($mode eq 'learn'){
		@$myFeatures = (0, 0, 0);
		# 0: 0-30
		# 1: 31-60
		# 2: 61-..
		
		
		if($value > 0 && $value <= 30){
			$$myFeatures[0] = "1";
		}
		elsif($value > 30 && $value <= 60){
			$$myFeatures[1] = "1";
		}
		elsif($value > 60){
			$$myFeatures[2] = "1";
		}
	}
	else{
		@$names = ("", "", "");
		$$names[0] = $features{$number}."[0-30]";
		$$names[1] = $features{$number}."[31-60]";
		$$names[2] = $features{$number}."[>61]";
	}
}

sub add_numExactFragmentsPerResidue{
	my($value, $myFeatures, $names, $number) = @_;
	if($mode eq 'learn'){
		@$myFeatures = (0, 0, 0, 0, 0);
		# 0: 0
		# 1: 1
		# 2: 2
		# 3: 3
		# 4: >=4
		
		if($value > 0 && $value <= 4){
			$$myFeatures[$value] = "1";
		}
		elsif($value > 4){
			$$myFeatures[4] = "1";
		}
	}
	else{	
		@$names = ("", "", "", "", "");
		$$names[0] = $features{$number}."[0]";
		$$names[1] = $features{$number}."[1]";
		$$names[2] = $features{$number}."[2]";
		$$names[3] = $features{$number}."[3]";
		$$names[4] = $features{$number}."[>4]";
	}
}

sub add_numApproxFragmentsPerResidue{
	my($value, $myFeatures, $names, $number) = @_;
	
	if($mode eq 'learn'){
		@$myFeatures = (0, 0, 0, 0);
		# 0: 0
		# 1: 1-2
		# 2: 3-4	
		# 3: 5-..

		if($value == 0){
			$$myFeatures[0] = "1";
		}
		elsif($value > 0 && $value <= 2){
			$$myFeatures[1] = "1";
		}
		elsif($value > 2 && $value <= 4){
			$$myFeatures[2] = "1";
		}
		elsif($value > 4){
			$$myFeatures[3] = "1";
		}
	}
	else{
		@$names = ("", "", "", "");
		$$names[0] = $features{$number}."[0]";
		$$names[1] = $features{$number}."[1-2]";
		$$names[2] = $features{$number}."[3-4]";
		$$names[3] = $features{$number}."[>4]";
	}
}

sub add_numExactAtomsPerResidue{
	my($value, $myFeatures, $names, $number) = @_;
	
	if($mode eq 'learn'){
		@$myFeatures = (0, 0, 0, 0, 0);
		# 0: 0
		# 1: 1-10
		# 2: 11-20	
		# 3: 21-30
		# 4: 30-..
		
		if($value == 0){
			$$myFeatures[0] = "1";
		}
		elsif($value > 0 && $value <= 10){
			$$myFeatures[1] = "1";
		}
		elsif($value > 10 && $value <= 20){
			$$myFeatures[2] = "1";
		}
		elsif($value > 20 && $value <= 30){
			$$myFeatures[3] = "1";
		}
		elsif($value > 30){
			$$myFeatures[4] = "1";
		}
	}
	else{
		@$names = ("", "", "", "", "");
		$$names[0] = $features{$number}."[0]";
		$$names[1] = $features{$number}."[1-10]";
		$$names[2] = $features{$number}."[11-20]";
		$$names[3] = $features{$number}."[21-30]";
		$$names[4] = $features{$number}."[>30]";
	}
}

sub add_numApproxAtomsPerResidue{
	my($value, $myFeatures, $names, $number) = @_;
	
	if($mode eq 'learn'){
		@$myFeatures = (0, 0, 0, 0, 0);
		# 0: 0
		# 1: 1-100
		# 2: 101-150	
		# 3: 151-200
		# 4: 200-..
		
		if($value == 0){
			$$myFeatures[0] = "1";
		}
		elsif($value > 0 && $value <= 100){
			$$myFeatures[1] = "1";
		}
		elsif($value > 100 && $value <= 150){
			$$myFeatures[2] = "1";
		}
		elsif($value > 150 && $value <= 200){
			$$myFeatures[3] = "1";
		}
		elsif($value > 200){
			$$myFeatures[4] = "1";
		}
	}
	else{
		@$names = ("", "", "", "", "");
		$$names[0] = $features{$number}."[0]";
		$$names[1] = $features{$number}."[1-100]";
		$$names[2] = $features{$number}."[101-150]";
		$$names[3] = $features{$number}."[151-200]";
		$$names[4] = $features{$number}."[>200]";
	}
}

sub add_avgConservationPerProtein{
	my($value, $myFeatures, $names, $number) = @_;
	
	if($mode eq 'learn'){
		@$myFeatures = (0, 0, 0, 0);
		# 0: 0-2
		# 1: 2-4
		# 2: 4-6	
		# 3: 6-..
		
		if($value > 0 && $value <= 2){
			$$myFeatures[0] = "1";
		}
		elsif($value > 2 && $value <= 4){
			$$myFeatures[1] = "1";
		}
		elsif($value > 4 && $value <= 6){
			$$myFeatures[2] = "1";
		}
		elsif($value > 6){
			$$myFeatures[3] = "1";
		}
	}
	else{
		@$names = ("", "", "", "");
		$$names[0] = $features{$number}."[0-2]";
		$$names[1] = $features{$number}."[2-4]";
		$$names[2] = $features{$number}."[4-6]";
		$$names[3] = $features{$number}."[>6]";
	}
}

sub add_conservationPerResidue{
	my($value, $myFeatures, $names, $number) = @_;
	
	if($mode eq 'learn'){	
		@$myFeatures = (0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
		$$myFeatures[$value] = "1";
	}
	else{
		@$names = ("", "", "", "", "", "", "", "", "", "");
		for(my $i = 0; $i <= 9; $i++){
			$$names[$i] = $features{$number}."[$i]";
		}
	}
}

sub add_residuePocketNumber{
	my($value, $myFeatures, $names, $number) = @_;
	if($mode eq 'learn'){
		@$myFeatures = (0, 0, 0, 0, 0, 0, 0, 0, 0);
		# 0, 1, 2, 3, 4, 5, 6-10, 11-20, >20
		
		if($value >= 0 && $value <= 5){
			$$myFeatures[$value] = "1";
		}
		elsif($value > 5 && $value <= 10){
			$$myFeatures[6] = "1";
		}
		elsif($value > 10 && $value <= 20){
			$$myFeatures[7] = "1";
		}
		elsif($value > 20){
			$$myFeatures[8] = "1";
		}
	}
	else{
		@$names = ("", "", "", "", "", "", "", "", "");
		for(my $i = 0; $i <= 5; $i++){
			$$names[$i] = $features{$number}."[$i]";
		}
		$$names[6] = $features{$number}."[6-10]";
		$$names[7] = $features{$number}."[11-20]";
		$$names[8] = $features{$number}."[>20]";		
	}
}

sub add_holesValuePerResidue{
	my($value, $myFeatures, $names, $number) = @_;
	if($mode eq 'learn'){
		@$myFeatures = (0, 0, 0, 0, 0, 0, 0, 0);
		# -1, <(-0.5), (-0.5)-0, 0-1, 1-2, 2-3, 3-4, >4
		
		if($value == -1){
			$$myFeatures[0] = "1";
		}
		elsif($value <= -0.5){
			$$myFeatures[1] = "1";
		}
		elsif($value > -0.5 && $value < 0){
			$$myFeatures[2] = "1";
		}
		elsif($value >= 0 && $value <= 1){
			$$myFeatures[3] = "1";
		}
		elsif($value > 1 && $value <= 2){
			$$myFeatures[4] = "1";
		}
		elsif($value > 2 && $value <= 3){
			$$myFeatures[5] = "1";
		}
		elsif($value > 3 && $value <= 4){
			$$myFeatures[6] = "1";
		}
		elsif($value > 4){
			$$myFeatures[7] = "1";
		}
	}
	else{
		@$names = ("", "", "", "", "", "", "", "");
		$$names[0] = $features{$number}."[-1]";
		$$names[1] = $features{$number}."[(-1)-(-0.5)]";
		$$names[2] = $features{$number}."[(-0.5)-0]";
		$$names[3] = $features{$number}."[0-1]";
		$$names[4] = $features{$number}."[1-2]";
		$$names[5] = $features{$number}."[2-3]";
		$$names[6] = $features{$number}."[3-4]";
		$$names[7] = $features{$number}."[>4]";		
	}
}

sub add_aaNumber{
	my($value, $myFeatures, $names, $number) = @_;
	if($mode eq 'learn'){
		@$myFeatures = (0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
						0, 0, 0, 0, 0, 0, 0, 0, 0, 0);#, 0);
		
		if($value != 21){
			$$myFeatures[$value-1] = "1";
		}
	}
	else{
		@$names = ("", "", "", "", "", "", "", "", "", "", 
				  "", "", "", "", "", "", "", "", "", "");#, "");
		#for(my $i = 0; $i < 21; $i++){
		for(my $i = 0; $i < 20; $i++){
			$$names[$i] = $features{$number}."[".($i+1)."]";
		}
	}
}
