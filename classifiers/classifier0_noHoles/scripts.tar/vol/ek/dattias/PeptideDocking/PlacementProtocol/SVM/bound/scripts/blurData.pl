#!/usr/bin/perl
# author: dattias
# blurData.pl

use strict;

my $outputMat = $ARGV[0]; # classification matrix
my $trainMat = $ARGV[1]; # input
my $resultPdbDir = $ARGV[2];
my $newClassificationMatrix = $ARGV[3];

my $selectRasScript = "../scripts/within4A.template.rasscript";
my $tmpRasScript = "tmp.rasscript";
`rm -f $tmpRasScript`;
my $selectionPdb = "selection.pdb";
`rm -f $selectionPdb`;
my $tmpPdb = "tmp.pdb";
`rm -f $tmpPdb`;

open(MAT, "<$trainMat") or die $!;
my @trainMatLines = <MAT>;
close(MAT);

open(MAT, "<$outputMat") or die $!;
chomp(my @outputMatLines = <MAT>);
close(MAT);

my $newClassStr = "";

my $inPdb = 0;
my $exampleIndex = 0;

my $pdb = "";
my $newPdb = "";
my $chain = "";
my %resultsHash = ();

my $newClassVal = 0;
my $classVal = 0;


foreach my $line(@trainMatLines){
	chomp($line);
	
	next if($line =~ m/^#/);
	
	if($line =~ m/#PDB (....)/){
		$newPdb = $1;
		
		if($newPdb ne $pdb){
			if($inPdb == 1){
				#print "finishing previous pdb...\n";
				#finishPdb($pdb);
			} # if($inPdb == 1)
	
			$pdb = $newPdb;
			print "\n** Starting $pdb\n";
			$inPdb = 1;
			
			chomp($chain = `getChain.pl $resultPdbDir/$pdb.results.pdb 1`);
			`extract_chains_and_range.pl -p $resultPdbDir/$pdb.results.pdb -c $chain -o $tmpPdb`;
			
			open(PDB, "<$tmpPdb") or die $!;
			foreach my $tmpLine(<PDB>){
				if($tmpLine =~ m/.{22}(....).{34}(......)/){
					my $resNum = $1;
					my $bFactor = $2;
					trim(\$resNum);
					trim(\$bFactor);
					$resultsHash{$resNum} = $bFactor;
				} 
			}
			close(PDB);
			
		} # if($newPdb ne $pdb)
		if($inPdb == 1){
			if($line =~ m/#.*Res ...(.*)/){
				my $resNum = $1;
				trim(\$resNum);
				
				# Get residue classification
				$classVal = $outputMatLines[$exampleIndex];
				$exampleIndex++;
				
				
				$newClassVal = findNewClassification($classVal, 
					"$resultPdbDir/$pdb.results.pdb", $chain, $resNum);
				
				$newClassStr .= $newClassVal."\n";
				#print "$resNum: $classVal => $newClassVal\n\n";
			} # if($line =~ m/#.*Res ...(.*)/)
		} # if($inPdb == 1)
		
	} # has #PDB # if($line =~ m/#PDB (....)/)
} # going over train mat # foreach my $line(@trainMatLines)

open(RES, ">$newClassificationMatrix") or die $!;
print RES "$newClassStr\n";
close(RES);


#######################################
sub findNewClassification{
	my ($oldClass, $pdbFile, $chain, $pos) = @_;
	
	# Create tmp script
	`rm -f $tmpRasScript`;
	open(FILE, "<$selectRasScript") or die $!;
	my @lines = <FILE>;
	close(FILE);
	open(FILE, ">$tmpRasScript") or die $!;
	foreach my $tmpLine(@lines){
		$tmpLine =~ s/_CHAIN_/$chain/g;
		$tmpLine =~ s/_RESNUM_/$pos/g;
		print FILE $tmpLine;
	}
	close(FILE);

	# Filter lonely pos results
	my $foundPosNeighbour = 0;
	`rm -f $selectionPdb`;
	my $cmd = "rasmol $pdbFile -nodisplay < $tmpRasScript";
	`$cmd`;
	if(! -e $selectionPdb){
		print "Selection file not created: $selectionPdb!\n";
		exit;
	}
	`rm -f $tmpRasScript`;
	chomp(my @rasout = `cat $selectionPdb | grep -v "^END" | sed 's/^.\\{22\\}\\(....\\).*/\\1/' | uniq`);

	my $sum = $oldClass;
	#print "$pos: ";
	foreach my $resNum(@rasout){
		trim(\$resNum);
	#	print "$resNum ";
		
		$sum += $resultsHash{$resNum};
	}
	#print "\n";
	
	my $newClass = $sum / (1+length(@rasout));
	
	if($newClass < 0.2){
		return 0;
	}
	else{
		return $newClass;
	}
}

sub trim{
	my ($str) = @_;
	$$str =~ s/\s//g;
}