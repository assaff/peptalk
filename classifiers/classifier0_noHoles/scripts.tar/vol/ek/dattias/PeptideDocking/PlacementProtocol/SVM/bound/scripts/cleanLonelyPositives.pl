#!/usr/bin/perl
# author: dattias
# cleanLonelyPositives.pl

use strict;

my $outputMat = $ARGV[0]; # classification matrix
my $trainMat = $ARGV[1]; # input
my $resultPdbDir = $ARGV[2];
my $newClassificationMatrix = $ARGV[3];

my $selectRasScript = "../scripts/within4A.template.rasscript";
my $tmpRasScript = "tmp.rasscript";
`rm -f $tmpRasScript`;
my $selectionPdb = "selection.pdb";
`rm -f $selectionPdb`;

open(MAT, "<$trainMat") or die $!;
my @trainMatLines = <MAT>;
close(MAT);

open(MAT, "<$outputMat") or die $!;
chomp(my @outputMatLines = <MAT>);
close(MAT);

my $newClassStr = "";

my $inPdb = 0;
my $exampleIndex = 0;

my $pdb = "";
my @pdbLines = ();
my $newPdb = "";
my @posScores = ();
my %posScoresHash = ();
my $chain = "";

my $newClassVal = 0;
my $classVal = 0;


foreach my $line(@trainMatLines){
	chomp($line);
	
	next if($line =~ m/^#/);
	
	if($line =~ m/#PDB (....)/){
		$newPdb = $1;
		
		if($newPdb ne $pdb){
			if($inPdb == 1){
				#print "finishing previous pdb...\n";
				#finishPdb($pdb);
			} # if($inPdb == 1)
	
			$pdb = $newPdb;
			print "\n** Starting $pdb\n";
			$inPdb = 1;
			
			open(PDB, "<$resultPdbDir/$pdb.scores") or die $!;
			@posScores = <PDB>;
			close(PDB);
			
			# Clean pos scores hash
			%posScoresHash = ();
			# Fill with pos scores
			foreach $line(@posScores){
				if($line =~ m/^... (.*) (.*)/){
					my $num = $1;
					my $score = $2;
					trim(\$num);
					trim(\$score);
					$posScoresHash{$num} = $score;
				} # if($line =~ m/^... (.*) (.*)/)
			} # foreach $line(@posScores)
			
			chomp($chain = `getChain.pl $resultPdbDir/$pdb.results.pdb 1`);
		} # if($newPdb ne $pdb)
		if($inPdb == 1){
			if($line =~ m/#.*Res ...(.*)/){
				my $resNum = $1;
				trim(\$resNum);
				
				# Get residue classification
				$classVal = $outputMatLines[$exampleIndex];
				$exampleIndex++;
				
				
				$newClassVal = findNewClassification($classVal, 
					"$resultPdbDir/$pdb.results.pdb", $chain, $resNum);
				
				$newClassStr .= $newClassVal."\n";
				print "$resNum: $classVal => $newClassVal\n\n";
			} # if($line =~ m/#.*Res ...(.*)/)
		} # if($inPdb == 1)
		
	} # has #PDB # if($line =~ m/#PDB (....)/)
} # going over train mat # foreach my $line(@trainMatLines)

open(RES, ">$newClassificationMatrix") or die $!;
print RES "$newClassStr\n";
close(RES);


#######################################
sub findNewClassification{
	my ($oldClass, $pdbFile, $chain, $pos) = @_;
	
	if($oldClass <= 0){
		# Neg result - OK
		return $oldClass;
	}
	
	# Create tmp script
	`rm -f $tmpRasScript`;
	open(FILE, "<$selectRasScript") or die $!;
	my @lines = <FILE>;
	close(FILE);
	open(FILE, ">$tmpRasScript") or die $!;
	foreach my $tmpLine(@lines){
		$tmpLine =~ s/_CHAIN_/$chain/g;
		$tmpLine =~ s/_RESNUM_/$pos/g;
		print FILE $tmpLine;
	}
	close(FILE);

	# Filter lonely pos results
	my $foundPosNeighbour = 0;
	`rm -f $selectionPdb`;
	my $cmd = "rasmol $pdbFile -nodisplay < $tmpRasScript";
	`$cmd`;
	if(! -e $selectionPdb){
		print "Selection file not created: $selectionPdb!\n";
		exit;
	}
	`rm -f $tmpRasScript`;
	chomp(my @rasout = `cat $selectionPdb | grep -v "^END" | sed 's/^.\\{22\\}\\(....\\).*/\\1/' | uniq`);

	print "$pos: ";
	foreach my $resNum(@rasout){
		trim(\$resNum);
		print "$resNum";
		
		if(exists $posScoresHash{$resNum}){
			print "+";
			$foundPosNeighbour = 1;
			last;
		}
		print " ";
	}
	print "\n";
	
	if($foundPosNeighbour == 0){
		return 0;
	}
	else{
		return $oldClass;
	}
}

sub trim{
	my ($str) = @_;
	$$str =~ s/\s//g;
}