function createFeatureDistributionMap(dataFilename)

% Feature Distribution Map
featureMat = importdata(dataFilename,' ');
[B, IX] = sort (featureMat, 1);
sortedFeatureMat = featureMat(IX(:,1), :);
sortedFeatureMat(sortedFeatureMat(:,1) == -1, 1) = 0;
imageHandle = imagesc(sortedFeatureMat);
imageName = [dataFilename '_featureDistribution.jpg'];
saveas(imageHandle,imageName);

end