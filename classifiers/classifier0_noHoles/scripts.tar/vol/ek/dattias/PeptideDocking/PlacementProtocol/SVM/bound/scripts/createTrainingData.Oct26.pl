#!/usr/bin/perl
# author: dattias
# createTrainingData.pl

use strict;
use Getopt::Long;
use FileHandle;

# Training on bound proteins

# Usage: createTrainingData.pl  [-full] [-pdb $name] [-out $outDir] [-burriedResiduesRedo] [-contactingResiduesRedo] [-holesRedo]
# 								[-predDir $predDirName]

##############################################################################################
# Handle command line arguments
##############################################################################################
my $fullRun = 0;				# Perform a fullRun (recreate all possible file info).
my $burriedResiduesRedo = 0; 	# Recreate info on burried residues.
my $contactingResiduesRedo = 0; # Recreate info on contacting residues.
my $holesRedo = 0; 				# Recreate info on holes residues.
my $pdb = "";					# Name of a single pdb ID on which to perform training.
my $outputDir = "results"; 		# Directory for output files.
my $predictionDir = "";			# When creating test data for prediction - this directory contains the predicted PDBs data

GetOptions ("full" => \$fullRun, 
			"pdb=s" => \$pdb,
			"out=s" => \$outputDir,
			"burriedResiduesRedo" => \$burriedResiduesRedo,
			"contactingResiduesRedo" => \$contactingResiduesRedo,
			"holesRedo" => \$holesRedo,
			"predDir=s" => \$predictionDir);
			
$outputDir = "../$outputDir"."_results";
#END##########################################################################################

##############################################################################################
# GENERAL DEFINITIONS
##############################################################################################
my $pdbList = "../boundPdbsList.forSvm.onlyEntireData.txt";
my $predPdbList = "list.txt";

my $conservationDir = "ConSurfAnalysis/data/";
my $ftMapDataDir = "FTMapAnalysis/ftmapData/";
my $castPDataDir = "CastPAnalysis/CastPData/";
my $rosettaHolesDataDir = "RosettaHoles/";
my $naccessSurfaceData = "SurfaceAccessability/naccessAnalysis/data/";
my $contactWithPeptideData = "ContactWithPeptide/data/";

my $mainBoundDir = "/vol/ek/dattias/PeptideDocking/PlacementProtocol/bound/";
my $mainUnboundDir = "/vol/ek/dattias/PeptideDocking/PlacementProtocol/unbound/";

my $unboundDbDir = "$mainUnboundDir/unboundSet/";
my $boundDbDir = "$mainBoundDir/boundSet/";
#my $dbDir = "/vol/ek/londonir/CleanPeptiDB/db/";

# Work modes
my $MODE_BOUND 		= "bound";
my $MODE_UNBOUND 	= "unbound";
my $MODE_PREDICT 	= "pred";

# Create output directory
my $i = 1;
my $finalOutputDir = $outputDir;
while(-e $finalOutputDir){
	$finalOutputDir = "$outputDir.$i";
	$i++;
}
$outputDir = $finalOutputDir;

print "Output directory: $outputDir\n";
mkdir $outputDir;
my $cmd = "tar -czf $outputDir/scripts.tar /vol/ek/dattias/PeptideDocking/PlacementProtocol/SVM/bound/scripts/";
`$cmd`;

# matlab
my $trainingMatFile = "$outputDir/trainMat";
my $testMatFile = "$outputDir/testMat";
# svm light
my $trainingMatFile_sl = "$outputDir/trainMat.svmlight";

my $rasmolPdbName = "rasmol.tmp.pdb";
my $rasmolLabelingPdbName = "rasmol.labeling.tmp.pdb";
my $residueLabelingRasScript = "residuesContactingPeptide.rasscript";
my $exactFragmentsRasScript = "findExactFragments.tmp.rasscript";
my $approxFragmentsRasScript = "findApproxFragments.tmp.rasscript";

# AA properties
my $PROP_NUM         = 0;
my $PROP_HYDROPHOBIC = 1;
my $PROP_POLAR       = 2;
my $PROP_AROMATIC    = 3;
my $PROP_ALIPHATIC   = 4;
my $PROP_HBONDING    = 5;
my %aaNameToProperties = ( #Num Hydrophobic Polar Aromatic Aliphatic Hbonding
   ALA =>   [1,  1, 0, 0, 1, 0],   ARG =>   [2,  0, 1, 0, 0, 1],   ASN =>   [3,  0, 1, 0, 0, 1],   ASP =>   [4,  0, 1, 0, 0, 1],   
   CYS =>   [5,  1, 1, 0, 0, 1],   GLN =>   [6,  0, 1, 0, 0, 1],   GLU =>   [7,  0, 1, 0, 0, 1],   GLY =>   [8,  1, 0, 0, 1, 0],   
   HIS =>   [9,  0, 1, 0, 0, 1],   ILE =>   [10, 1, 0, 0, 1, 0],   LEU =>   [11, 1, 0, 0, 1, 0],   LYS =>   [12, 0, 1, 0, 0, 1],  
   MET =>   [13, 1, 0, 0, 0, 0],   PHE =>   [14, 1, 0, 1, 0, 0],   PRO =>   [15, 1, 0, 0, 1, 1],   SER =>   [16, 0, 1, 0, 0, 1],  
   THR =>   [17, 0, 1, 0, 0, 1],   TRP =>   [18, 1, 0, 1, 0, 1],   TYR =>   [19, 1, 1, 1, 0, 1],   VAL =>   [20, 1, 0, 0, 1, 0],  
   OTHER => [21, 0, 0, 0, 0, 0]
);

my @pdbs = ();
if($pdb eq ""){
	my $currPdbList = ($predictionDir eq "") ? $pdbList : "$predictionDir$predPdbList";
	print "LIST FILE: $currPdbList\n";
	open(LIST, $currPdbList) or die $!;
	chomp(@pdbs = <LIST>);
	@pdbs = grep(/^....$/, @pdbs);
	print "pdbs @pdbs\n";
	close(LIST);
}
else{
	@pdbs = ($pdb);
}

#END##########################################################################################

my $trainFH = new FileHandle;
my $testFH = new FileHandle;

$trainFH->open(">$trainingMatFile") or die $!;
$testFH->open(">$testMatFile") or die $!;

# open(OUT_SL, ">$trainingMatFile_sl") or die $!;
# open(OUT, ">$trainingMatFile") or die $!;
# open(OUT_TEST, ">$testMatFile") or die $!;

outputLabels("#label",
			# "numFragmentsPerProtein".
			# "avgAtomsPerFragmentPerProtein",
			"numExactFragmentsPerResidue_relative",
			"numApproxFragmentsPerResidue_relative",
			"numExactAtomsPerResidue_relative",
			"numApproxAtomsPerResidue_relative",
			# "numExactFragmentsPerResidue",
			# "numApproxFragmentsPerResidue",
			# "numExactAtomsPerResidue",
			# "numApproxAtomsPerResidue",
			# "avgConservationPerProtein",
			"conservationPerResidue",
			"relativeConservationPerResidue",
			"residueMoreConservedThanAvg",
			"residueInPocket",
			"residuePocketNumber",
			"holesValuePerResidue",
			"AA_HYDROPHOBIC",
			# "AA_NUM",
			"AA_POLAR",
			"AA_AROMATIC",
			"AA_ALIPHATIC",
			"AA_HBONDING"
			);

foreach my $pdb(@pdbs){

	print "PDB $pdb: ".localtime(time)."\n";
	
	if($predictionDir eq ""){
		# Learn with bound, test with unbound
		createResultsForPdb($pdb, $mainBoundDir, "$boundDbDir/mainChain/$pdb.A.pdb", $trainFH, $MODE_BOUND);
		
		if(-e "$unboundDbDir/$pdb.pdb"){
			createResultsForPdb($pdb, $mainUnboundDir, "$unboundDbDir/$pdb.pdb", $testFH, $MODE_UNBOUND);
		}
	}
	else{
		# create test matrix for predictions
		createResultsForPdb($pdb, $predictionDir, "$predictionDir/pdbs/$pdb.pdb", $testFH, $MODE_PREDICT);
	}
}

chdir $outputDir;

# close (OUT);
# close (OUT_SL);
# close (OUT_TEST);
$trainFH->close;
$testFH->close;

################################################################
sub createResultsForPdb{
	my ($pdb, $directory, $mainChain, $fh, $mode) = @_;
	
	my $currConservationDir = "$directory/$conservationDir";
	my $currFtMapDataDir = "$directory/$ftMapDataDir";
	my $currCastPDataDir = "$directory/$castPDataDir";
	my $currRosettaHolesDataDir = "$directory/$rosettaHolesDataDir";
	my $currNaccessSurfaceData = "$directory/$naccessSurfaceData";
	my $currContactWithPeptideData = "$directory/$contactWithPeptideData";
	
	#1) Get all properties
	#2) Go over each residue number:
	#		- print residue properties to Training Matrix
	
	open(PDB, "<$mainChain");
	chomp(my @resLines = grep(/^ATOM .* CA /, <PDB>));
	close(PDB);

	my $resNumShift = -1;
	if($resLines[0] =~ /^ATOM..................(....) /){
		$resNumShift = $1 - 1;
	}
	else{
		die ("\tError: $mode pdb file has wrong format");
	}
	
	# Clear arrays
	my %burriedResidues = ();
	my %contactingResidues = ();
	my %numExactFragmentsPerResidue = ();
	my %numApproxFragmentsPerResidue = ();
	my %numExactAtomsPerResidue = ();
	my %numApproxAtomsPerResidue = ();
	my %conservationPerResidue = ();
	my %residueMoreConservedThanAvg = ();
	my %holesValuePerResidue = ();
	my %residueInPocket = ();
	my %residuePocketNumber = ();
	my %numExactFragmentsPerResidue_relative = ();
	my %numApproxFragmentsPerResidue_relative = ();
	my %numExactAtomsPerResidue_relative = ();
	my %numApproxAtomsPerResidue_relative = ();
	my %relativeConservation = ();
	my $avgConservationPerProtein = "";
	my $numFragmentsPerProtein = "";
	my $avgAtomsPerFragmentPerProtein = "";
	
	# Get data
	getBurriedResidues($pdb, $currNaccessSurfaceData, \%burriedResidues, $mainChain);
	rosettaHolesProperties($pdb, $currRosettaHolesDataDir, \%holesValuePerResidue, $resNumShift, $mainChain);
	pocketProperties($pdb, $currCastPDataDir, \%residueInPocket, \%residuePocketNumber);
	conservationProperties($pdb, $currConservationDir, \%burriedResidues, 
		\$avgConservationPerProtein, \%conservationPerResidue, \%residueMoreConservedThanAvg, \%relativeConservation);
	ftMapProperties($pdb, $mainChain, $currFtMapDataDir, \$numFragmentsPerProtein, \$avgAtomsPerFragmentPerProtein,
		\%numExactFragmentsPerResidue, \%numApproxFragmentsPerResidue, \%numExactAtomsPerResidue, \%numApproxAtomsPerResidue,
		\%numExactFragmentsPerResidue_relative, \%numApproxFragmentsPerResidue_relative,
		\%numExactAtomsPerResidue_relative, \%numApproxAtomsPerResidue_relative);
	getLabels($pdb, $currContactWithPeptideData, \%contactingResidues, $mode, $mainChain);
	
# 	my @burriedList = keys %burriedResidues;
# 	print "burriedResidues: @burriedList\n";
# 	my @contactingList = keys %contactingResidues;
# 	print "contactingResidues: @contactingList\n";

	foreach my $line(@resLines){
		#ATOM      2  CA  VAL A   2      15.037  34.451  76.538  1.00 27.91           C
		if($line =~ m/^ATOM ......  CA  (...) .(....) /){
			my $resName = $1;
			my $resNum = $2;
			trim(\$resNum);
			
			# Working ONLY on surface residues
			next if(exists $burriedResidues{$resNum});
			
			# handle missing data #
			my $res_holesValuePerResidue = getValue($resNum, \%holesValuePerResidue, -1);
			my $res_residueInPocket = getValue($resNum, \%residueInPocket, 0);
			my $res_residuePocketNumber = getValue($resNum, \%residuePocketNumber, 0);
			my $res_conservationPerResidue = getValue($resNum, \%conservationPerResidue, 0);
			my $res_residueMoreConservedThanAvg = getValue($resNum, \%residueMoreConservedThanAvg, -1);
			my $res_numApproxAtomsPerResidue = getValue($resNum, \%numApproxAtomsPerResidue, -1);
			my $res_numApproxFragmentsPerResidue = getValue($resNum, \%numApproxFragmentsPerResidue, -1);
			my $res_numExactAtomsPerResidue = getValue($resNum, \%numExactAtomsPerResidue, -1);
			my $res_numExactFragmentsPerResidue = getValue($resNum, \%numExactFragmentsPerResidue, -1);
			my $res_numApproxAtomsPerResidue_relative = getValue($resNum, \%numApproxAtomsPerResidue_relative, -1);
			my $res_numApproxFragmentsPerResidue_relative = getValue($resNum, \%numApproxFragmentsPerResidue_relative, -1);
			my $res_numExactAtomsPerResidue_relative = getValue($resNum, \%numExactAtomsPerResidue_relative, -1);
			my $res_numExactFragmentsPerResidue_relative = getValue($resNum, \%numExactFragmentsPerResidue_relative, -1);
			my $res_relativeConservation = getValue($resNum, \%relativeConservation, 0);

			my $label = ($mode eq $MODE_PREDICT) ? 0 : getValue($resNum, \%contactingResidues, "-1");
			
			outputResults($fh, $pdb, $resName, $resNum, $label, 
					## FTMap
					#$numFragmentsPerProtein, $avgAtomsPerFragmentPerProtein, 
					$res_numExactFragmentsPerResidue_relative, 
					$res_numApproxFragmentsPerResidue_relative,
					$res_numExactAtomsPerResidue_relative, 
					$res_numApproxAtomsPerResidue_relative,
					#$res_numExactFragmentsPerResidue, $res_numApproxFragmentsPerResidue, $res_numExactAtomsPerResidue, $res_numApproxAtomsPerResidue,
					## ConSurf
					#$avgConservationPerProtein, $res_conservationPerResidue, $res_residueMoreConservedThanAvg, 
					$res_conservationPerResidue, 
					$res_relativeConservation, 
					$res_residueMoreConservedThanAvg, 
					## CastP
					$res_residueInPocket, 
					$res_residuePocketNumber, 
					## RosettaHoles
					$res_holesValuePerResidue,
					## AA Properties
					#getAAProperty($resName, $PROP_NUM), 
					getAAProperty($resName, $PROP_HYDROPHOBIC), 
					getAAProperty($resName, $PROP_POLAR), 
					getAAProperty($resName, $PROP_AROMATIC),
					getAAProperty($resName, $PROP_ALIPHATIC), 
					getAAProperty($resName, $PROP_HBONDING) 
				);
		}
	}
}

sub outputResults{
	my ($fh, $pdb, $resName, $resNum, $label, @features) = @_;
	
	my @numberedFeatures = @features;
	numberArray(\@numberedFeatures);
	
	my $featureStr = join(" ", @features);
	my $numberedFeatureStr = join(" ", @numberedFeatures);
	
	my $infoStr = "#PDB $pdb Res $resName$resNum";
	
# 	print OUT "$label $featureStr $infoStr\n";
# 	print OUT_SL "$label $numberedFeatureStr $infoStr\n";
	print $fh "$label $featureStr $infoStr\n";
}

sub outputLabels{
	my ($label, @features) = @_;
	
	numberArray(\@features);
	my $featureStr = join(" ", @features);
	
# 	print OUT "$label $featureStr\n";
# 	print OUT_SL "$label $featureStr\n";
# 	print OUT_TEST "$label $featureStr\n";
# 	
	print $trainFH "$label $featureStr\n";
	print $testFH "$label $featureStr\n";
}

sub numberArray{
	my ($array) = @_;
	
	for(my $i = 0; $i < scalar @$array; $i++){
		$$array[$i] = ($i+1).":".$$array[$i];
	}
}

sub getValue{
	my($num, $array, $defaultVal) = @_;
	if(exists $$array{$num}){
		return $$array{$num};
	}
	else{
		return $defaultVal;
	}
}

sub trim{
	my ($str) = @_;
	$$str =~ s/\s//g;
}

sub getAAProperty{
	my ($name, $propNum) = @_;
	my $propList;
	if(exists $aaNameToProperties{$name}){
		$propList = $aaNameToProperties{$name};
	}
	else{
		$propList = $aaNameToProperties{OTHER};
	}
	return $$propList[$propNum];
}

sub getCloseResidues{
	my ($pdb, $pdbFile, $contactingResidues) = @_;
	
	# create rasmol model
	open(MODEL, ">$rasmolLabelingPdbName") or die $!;

	print MODEL "MODEL        0\n";
	open(PDB, "<$pdbFile") or die $!;
	print MODEL <PDB>;
	close(PDB);
	print MODEL "ENDMDL\n";
	print MODEL "MODEL        1\n";
	open(PDB, "<$boundDbDir/peptidesOnly/$pdb.peptide.pdb") or die $!;
	print MODEL <PDB>;
	close(PDB);
	print MODEL "ENDMDL\n";

	close MODEL;
	# DONE: create rasmol model
	
	chomp(my @rasout = `rasmol $rasmolLabelingPdbName -script $residueLabelingRasScript -nodisplay`);
	#chomp(my @rasout = `rasmol $boundDbDir/$pdb.pdb -script $residueLabelingRasScript -nodisplay`);
	my @results = grep(/Chain: .* Group: .*/, @rasout);
	foreach my $res(@results){
		#Chain: B  Group:  HIS   1 (C)   (10/10) atoms
		if($res =~ m/.*Chain: .  Group:  (...)(....)/){
			my $resName = $1;
			my $resNum = $2;
			trim(\$resNum);
			
			$$contactingResidues{$resNum} = "+1";
		}
	}
}

# Only for bound!!!
sub getContactingResidues{
	my ($pdb, $workDir, $contactingResidues) = @_;
	
	if($fullRun || $contactingResiduesRedo){
		`rm -f $workDir$pdb.*`;
		my $cmd = "(reduce -FLIPs $boundDbDir$pdb.pdb > $workDir$pdb.H.pdb) >& /dev/null\n";
		`$cmd`;
		if(!(-e "$workDir$pdb.H.pdb")){
			die ("\tError: reduce failed on $boundDbDir$pdb.pdb");
		}
		
		$cmd = "(/vol/ek/share/bin/probe -NOHET -NOWATer -MC -U \"ALL\" $workDir$pdb.H.pdb > $workDir$pdb.kin) >& /dev/null\n";
		`$cmd`;
		if(!(-e "$workDir$pdb.kin")){
			die ("\tError: probe failed on $workDir$pdb.H.pdb");
		}
	}
	else{
		if(! (-e "$workDir$pdb.kin")){
			return;
		}
	}

	open(CONTS, "<$workDir$pdb.kin") or die $!;
	my @lines = grep(/ A .* : B .* /, <CONTS>);
	close(CONTS);
	
	foreach my $line(@lines){
		my @parts = split(/:/, $line);
		if($parts[11] >= 0.06){
			# $parts[3] holds the protein residue details
			if($parts[3] =~ m/^ .(....) ... /){
				my $protResNum = $1;
				trim(\$protResNum);
				$$contactingResidues{$protResNum} = "+1";
			}
		}
	}
}

sub getLabels{
	my ($pdb, $workDir, $contactingResidues, $mode, $pdbFile) = @_;
	
	if($mode eq $MODE_PREDICT){
		return;
	}
	
	if($mode eq $MODE_BOUND){
		getContactingResidues($pdb, $workDir, $contactingResidues);
	}
	else{
		getCloseResidues($pdb, $pdbFile, $contactingResidues);
	}
}

# $holesValuePerResidue - Avg holes value
sub rosettaHolesProperties{
	my($pdb, $workDir, $holesValuePerResidue, $resNumShift, $pdbFile) = @_;
	
	my $localPdbName = "$pdb.mainChain.pdb";
	if($fullRun || $holesRedo){
		`rm -f $workDir$pdb.*`;
		# Create RosettaHoles data
		chomp(my $currentDir = `pwd`);
		chdir $workDir;
		my $cmd = "ln -s $pdbFile $localPdbName";
		`$cmd`;
		#$cmd = "/cs/alum/londonir/lab/rosetta/mini/bin/holes.linuxgccrelease -database /vol/ek/londonir/rosetta/minirosetta_database/ ".
		#		"-holes:dalphaball /vol/ek/share/bin/DAlphaBall -holes:make_pdb -holes:make_voids -s $localPdbName > $pdb.log";
		#$cmd = "/vol/ek/londonir/rosetta/mini/build/src/release/linux/2.6/32/x86/gcc/holes.linuxgccrelease -database /vol/ek/londonir/rosetta/minirosetta_database/ ".
		#		"-holes:dalphaball /vol/ek/share/bin/DAlphaBall -holes:make_pdb -holes:make_voids -s $localPdbName > $pdb.log";
		$cmd = "/vol/ek/share/rosetta/mini/build/src/release/linux/2.6/32/x86/gcc/holes.linuxgccrelease -database /vol/ek/share/rosetta/minirosetta_database/ ".
				"-holes:dalphaball /vol/ek/share/bin/DAlphaBall -holes:make_pdb -holes:make_voids -s $localPdbName > $pdb.log";
		`$cmd`;
		chdir $currentDir;
	}
	
	if(!(-e "$workDir/$localPdbName"."_cavs.pdb")){
		return;
	}
	
	open(HOLES, "$workDir/$localPdbName"."_cavs.pdb") or die $!;
	my @holesLines = <HOLES>;
	close(HOLES);
	
	my $inRes = 0;
	my $resSum = 0;
	my $currRes = 0;
	my $numAtoms = 0;
	foreach my $line(@holesLines){
		#ATOM      1  N   VAL A   1      13.699  35.104  76.557  1.00 -0.22
		if($line =~ m/^ATOM..................(....)   .*(......)$/){
			my $resNum = $1;
			my $value = $2;
			trim(\$resNum);
			trim(\$value);
			$resNum += $resNumShift;
			
			if($inRes == 1 and $resNum != $currRes){
				$inRes = 0;
				#make avg
				$$holesValuePerResidue{$currRes} = $resSum/$numAtoms;
				#print "Holes: $currRes -> ".$$holesValuePerResidue{$currRes}."\n";
			}
			if($inRes == 0){
				$resSum = 0;
				$numAtoms = 0;
				$currRes = $resNum;
				$inRes = 1;
			}
			$resSum += $value;
			$numAtoms ++;
		}
		elsif($inRes == 1){
			$inRes = 0;
			#make avg
			$$holesValuePerResidue{$currRes} = $resSum/$numAtoms;
			#print "Holes: $currRes -> ".$$holesValuePerResidue{$currRes}."\n";
		}
	}
}

# pocket rank does not include cavities
sub pocketProperties{
	my ($pdb, $workDir, $residueInPocket, $residuePocketNumber) = @_;
	
	my $castPDir = "$workDir/$pdb";
	if(!(-e $castPDir)){
		return;
	}
	
	my %pocketRank;
	#POC: ./uploa  86   0  1373.521  3000.55   743.303  3560.20  1385.80  694
	`cat $castPDir/$pdb.pocInfo | grep -v Molecule | egrep -v "^POC: ./uploa....   0" | sort -nr -k 5 > $castPDir/$pdb.pocInfo.sorted`;
	open(POC_INFO, "$castPDir/$pdb.pocInfo.sorted") or die $!;
	my @pocketLines = <POC_INFO>;
	close(POC_INFO);
	my $rank = 1;
	foreach my $line(@pocketLines){
		#POC: ./uploa  10   1 
		if($line =~ m/^POC: .\/uploa (...)/){
			my $pocketNumber = $1;
			trim(\$pocketNumber);
			
			$pocketRank{$pocketNumber} = $rank;
			#print "pocket ranks: pocket $pocketNumber, rank $rank\n";
			$rank++;
		}
	}

	open(POC_INFO, "$castPDir/$pdb.poc") or die $!;
	chomp(@pocketLines = <POC_INFO>);
	close(POC_INFO);
	foreach my $line(@pocketLines){
		#              ATOM      6  CG1 VAL A   2      14.482  32.751  78.306  1.00 30.46  13  POC
		if($line =~ m/^ATOM..................(....) .* (...)  POC/){
			my $residueNumber = $1;
			my $pocketNumber  = $2;
			trim(\$residueNumber);
			trim(\$pocketNumber);
			
			if(exists $pocketRank{$pocketNumber}){
				$$residueInPocket{$residueNumber} = 1;
				if(exists $pocketRank{$pocketNumber}){
					$$residuePocketNumber{$residueNumber} = $pocketRank{$pocketNumber};
				}
				else{
					$$residuePocketNumber{$residueNumber} = 0;
				}
				#print "pocket: res $residueNumber, pocket $pocketNumber, pocketRank ".$pocketRank{$pocketNumber}."\n";
			}
		}
	}
}

# $avgConservationPerProtein - over surface proteins
sub conservationProperties{
	my ($pdb, $workDir, $burriedResidues,
		$avgConservationPerProtein, $conservationPerResidue, $residueMoreConsurvedThanAvg, $relativeConservation) = @_;
	
	my $conservationFile = "$workDir/$pdb/pdbFILE_view_ConSurf.pdb";
	if(!(-e $conservationFile)){
		$$avgConservationPerProtein = 0;
		return;
	}
	
	open(FILE, "<$conservationFile") or die $!;
	chomp (my @lines = grep(/ CA /, <FILE>));
	close (FILE);
	
	my $sum = 0;
	my $numExposed = 0;
	foreach my $line(@lines){
		my $resNum = $line;
		#ATOM      2  CA  VAL A   1      16.373  33.731  77.460  1.00     8
		$resNum =~ s/^.{22}(....).*/$1/;
		trim(\$resNum);
		
		my $conservationNum = $line;
		$conservationNum =~ s/^.{65}(.).*/$1/;
		if(!exists $$burriedResidues{$resNum}){
			$sum += $conservationNum;
			$numExposed++;
		}
		
		$$conservationPerResidue{$resNum} = $conservationNum;
		#print "conservation: $resNum -> $conservationNum\n";
	}
	
	#$$avgConservationPerProtein = $sum / scalar(@lines);
	$$avgConservationPerProtein = $sum / $numExposed;
	#print "conservation: AVG -> $$avgConservationPerProtein\n";
	
	my $val;
	foreach my $resNum(keys %$conservationPerResidue){
		$val = 0;
		
		if($$conservationPerResidue{$resNum} > $$avgConservationPerProtein){
			$val = 1;
		}
		
		$$residueMoreConsurvedThanAvg{$resNum} = $val;
# 		print "RES '$resNum': AVG '$$avgConservationPerProtein', CONS '$conservationPerResidue{$resNum}', FINAL '$val'\n";
	}
	
	foreach my $resNum(keys %$conservationPerResidue){
		$$relativeConservation{$resNum} = ($$conservationPerResidue{$resNum} / $$avgConservationPerProtein);
	}
}

sub ftMapProperties{
	my ($pdb, $pdbFile, $workDir, $numFragmentsPerProtein, $avgAtomsPerFragmentPerProtein,
		$numExactFragmentsPerResidue, $numApproxFragmentsPerResidue,
		$numExactAtomsPerResidue, $numApproxAtomsPerResidue,
		$numExactFragmentsPerResidue_relative, $numApproxFragmentsPerResidue_relative,
		$numExactAtomsPerResidue_relative, $numApproxAtomsPerResidue_relative) = @_;
		
	if(! (-e "$workDir/$pdb.map.pdb")){
		# No FTMap data available
		$numFragmentsPerProtein = 0;
		$avgAtomsPerFragmentPerProtein = 0;
		print "\tERROR: No FTMap data available for $pdb in dir $workDir\n";
		return;
	}
	if(! (-e "$workDir/$pdb.map.clean.pdb")){
		createCleanFTMapFile($pdb, $workDir);
	}
	
	findFragmentStatisticsPerProtein($pdb, $workDir, $numFragmentsPerProtein, $avgAtomsPerFragmentPerProtein);
	findFragmentStatisticsPerResidue($pdb, $pdbFile, $workDir, 
		$numExactFragmentsPerResidue, $numApproxFragmentsPerResidue, $numExactAtomsPerResidue, $numApproxAtomsPerResidue, 
		$numExactFragmentsPerResidue_relative, $numApproxFragmentsPerResidue_relative,
		$numExactAtomsPerResidue_relative, $numApproxAtomsPerResidue_relative,
		$numFragmentsPerProtein, $avgAtomsPerFragmentPerProtein);
		
}

sub findFragmentStatisticsPerProtein{
	my($pdb, $workDir, $numFragmentsPerProtein, $avgAtomsPerFragmentPerProtein) = @_;
	
	my $ftmapData = "$workDir/$pdb.map.pdb";
	open(FILE, "<$ftmapData");
	chomp( my @lines = <FILE> );
	close (FILE);
	
	my @clusters = grep(/HEADER crosscluster/, @lines);
	$$numFragmentsPerProtein = scalar @clusters;
	if($$numFragmentsPerProtein == 0){
		$$avgAtomsPerFragmentPerProtein = 0;
		return;
	}
	
	my @atoms = grep(/^ATOM/, @lines);
	my $numAtomsInAllFragments = scalar @atoms;
	$$avgAtomsPerFragmentPerProtein = $numAtomsInAllFragments/$$numFragmentsPerProtein;
	#print "FTMap: num fragments $$numFragmentsPerProtein, avg atoms $$avgAtomsPerFragmentPerProtein, all atoms $numAtomsInAllFragments\n";
}

sub createCleanFTMapFile{
        my ($pdb, $workDir) = @_;

        open(FILE, "<$workDir/$pdb.map.pdb") or die $!;
        open(FILE_OUT, ">$workDir/$pdb.map.clean.pdb") or die $!;

        my $inProtein = 1;
        foreach my $line(<FILE>){
                if($inProtein == 1 and $line =~ m/^HEADER crosscluster/){
                        $inProtein = 0;
                }
                if($inProtein == 0){
                        print FILE_OUT $line;
                }
        }

        close(FILE_OUT);
        close(FILE);
}

sub findFragmentStatisticsPerResidue{
	my ($pdb, $pdbFile, $workDir, 
		$numExactFragmentsPerResidue, $numApproxFragmentsPerResidue, $numExactAtomsPerResidue, $numApproxAtomsPerResidue,
		$numExactFragmentsPerResidue_relative, $numApproxFragmentsPerResidue_relative,
		$numExactAtomsPerResidue_relative, $numApproxAtomsPerResidue_relative,
		$numFragmentsPerProtein, $avgAtomsPerFragmentPerProtein ) = @_;
				
	# create rasmol model
	open(MODEL, ">$rasmolPdbName") or die $!;

	print MODEL "MODEL        0\n";
	open(PDB, "<$pdbFile") or die $!;
	my @pdbLines = <PDB>;
	print MODEL @pdbLines;
	close(PDB);
	print MODEL "ENDMDL\n";

	print MODEL "MODEL        1\n";
	open(PDB, "<$workDir/$pdb.map.clean.pdb") or die $!;
	print MODEL <PDB>;
	close(PDB);
	print MODEL "ENDMDL\n";

	close MODEL;
	# DONE: create rasmol model
	
	my @pdbResLines = grep(/^ATOM .* CA /, @pdbLines);
	foreach my $resLine(@pdbResLines){
		#ATOM     32  C   VAL A   5
		#ATOM   4130  CA  PHE C 491      23.154  -2.178   6.971  1.00 45.33           C
		if($resLine =~ m/^ATOM........ CA  (...) .(....)/){
			my $resName = $1;
			my $resNum = $2;
			trim(\$resNum);
			
			findNumFragmentsPerResidue($resName, $resNum, $numExactFragmentsPerResidue, $numExactAtomsPerResidue,
				$numExactFragmentsPerResidue_relative, $numExactAtomsPerResidue_relative, 2.5, $exactFragmentsRasScript,
				$numFragmentsPerProtein, $avgAtomsPerFragmentPerProtein);
			findNumFragmentsPerResidue($resName, $resNum, $numApproxFragmentsPerResidue, $numApproxAtomsPerResidue, 
				$numApproxFragmentsPerResidue_relative, $numApproxAtomsPerResidue_relative, 4.0, $approxFragmentsRasScript,
				$numFragmentsPerProtein, $avgAtomsPerFragmentPerProtein);
		}
	}
}

sub findNumFragmentsPerResidue{
	my ($resName, $resNum, $numFragmentsPerResidue, $numAtomsPerResidue, $numFragmentsPerResidue_relative, $numAtomsPerResidue_relative, 
	$distance, $scriptName, $numFragmentsPerProtein, $avgAtomsPerFragmentPerProtein) = @_;

	open(SCRIPT, ">$scriptName") or die $!;
	my $selectCmd = sprintf("select within (%.2f, (%s%d and */0)) and not */0\n", $distance, $resName, $resNum);
	#print $selectCmd;
	print SCRIPT $selectCmd;
	print SCRIPT "show selected\nquit\n";
	close(SCRIPT);
	
	my $numFrags = 0;
	my $numFragAtoms = 0;
	my %chains;
	chomp(my @rasout = `rasmol $rasmolPdbName -script $scriptName -nodisplay`);
	my @results = grep(/Chain: .* Group: .*/, @rasout);
	foreach my $res(@results){
		if($res =~ m/.*Chain: (.)  Group:.*\((.*)\/.*/){
			my $chain = $1;
			my $hits = $2;
			
			if(!exists $chains{$chain}){
				$chains{$chain} = 1;
				$numFrags++;
			}
			$numFragAtoms += $hits;
		}
	}
	$$numFragmentsPerResidue{$resNum} = $numFrags;
	$$numAtomsPerResidue{$resNum} = $numFragAtoms;
# 	print "FTMap: distance -> $distance, resNum -> $resNum, fragments $numFrags, atoms $numFragAtoms\n";
	if($$numFragmentsPerProtein != 0 && $$numFragmentsPerResidue{$resNum} != 0){
		$$numFragmentsPerResidue_relative{$resNum} = $$numFragmentsPerResidue{$resNum} / $$numFragmentsPerProtein;
	}
	else{
		$$numFragmentsPerResidue_relative{$resNum} = 0;
	}
# 	print "FTMAP: frags_per_protein ".$$numFragmentsPerProtein." frags_per_res ".$$numFragmentsPerResidue{$resNum}." relative ".$$numFragmentsPerResidue_relative{$resNum}."\n";
	
	if($$avgAtomsPerFragmentPerProtein != 0 && $$numAtomsPerResidue{$resNum} != 0){
		$$numAtomsPerResidue_relative{$resNum} = ($$numAtomsPerResidue{$resNum} / 
		($$avgAtomsPerFragmentPerProtein*$$numFragmentsPerResidue{$resNum}) );
	}
	else{
		$$numAtomsPerResidue_relative{$resNum} = 0;
	}
# 	print "FTMAP: atoms_per_protein ".$$avgAtomsPerFragmentPerProtein." atoms_per_res ".$$numAtomsPerResidue{$resNum}." relative ".$$numAtomsPerResidue_relative{$resNum}."\n";
}

sub getBurriedResidues{
	my ($pdb, $workDir, $burriedResidues, $pdbFile) = @_;
	
	if($fullRun || $burriedResiduesRedo){
		# Create naccess data
		chomp(my $currentDir = `pwd`);
		chdir $workDir;
		# removing old data
		`rm -f $pdb.*`;
		my $cmd = "ln -s $pdbFile $pdb.mainChain.pdb";
		`$cmd`;
		$cmd = "/vol/ek/share/bin/naccess $pdb.mainChain.pdb";
		`$cmd`;
		chdir $currentDir;
	}
	
	if(! (-e "$workDir$pdb.rsa")){
		die("\tERROR: missing surface access file: $workDir$pdb.rsa\n");
	}
	
	open(SURF, "<$workDir$pdb.rsa") or die $!;
	#my @lines = grep(/^RES [A-Z]{3} A[0-9 ]{4}      .00/, <SURF>);
	my @allLines = <SURF>;
	close(SURF);
	
	#RES VAL A   1   149.58  98.8  90.46  79.2  59.12 159.1  93.51  81.0  56.07 155.9
	my @lines = ();
	foreach my $line(@allLines){
		if($line =~ m/^RES [A-Z]{3} A[0-9 ]{4} [0-9\. ]{8} (.....)/){
			my $relativeAccessabilityOverAllAtoms = $1;
			if($relativeAccessabilityOverAllAtoms < 1.0){
				@lines = (@lines, $line);
			}
		}
	}
	
	if(scalar @lines == 0){
		print ("\tWARNING: found no burried residues\n");
	}
	
	foreach my $line (@lines){
		$line =~ s/^RES ... A(....).*/$1/;
		trim(\$line);
		$$burriedResidues{$line} = 1;
	}
}
