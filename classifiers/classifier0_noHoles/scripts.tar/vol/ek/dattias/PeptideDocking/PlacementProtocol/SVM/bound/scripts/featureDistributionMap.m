% Feature Distribution Map
featureMat = importdata('trainMat.forMatlab',' ');
[B, IX] = sort (featureMat, 1);
sortedFeatureMat = featureMat(IX(:,1), :);
imageHandle = imagesc(sortedFeatureMat);
xlabel('1:Labels, 2-end: Features');
ylabel('Observations');
title('Training Set: Distribution of Features amongst negative and positive Observations');
saveas(imageHandle,'featureDistribution.train.jpg');