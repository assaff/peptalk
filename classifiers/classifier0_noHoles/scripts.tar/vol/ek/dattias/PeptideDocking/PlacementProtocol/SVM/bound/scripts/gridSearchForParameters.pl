#!/usr/bin/perl
# author: dattias
# gridSearchForParameters.pl

use strict;

my $trainingMatrix = $ARGV[0]; 

