#!/usr/bin/perl
# author: dattias
# normalizeSampleData.pl

use strict;
use Getopt::Long;

# Usage: normalizeSampleData.pl [-trainMat trainingMatrix] # should be ../results/trainMat
#								[-testMat testMatrix] 
#								[-trainOut normalizedTrainingMatrix] 
#								[-testOut normalizedTestMatrix] 
#								[-namesOut featureNames] 
#								#[-normalizationFactorsOut normalizationRanges]#
#								[-matlabTrainOut normalizedTrainMatrixForMatlab] 
#								[-matlabTestOut normalizedTestMatrixForMatlab]

##############################################################################################
# Handle command line arguments
##############################################################################################
my $trainMat = "";
my $testMat = "";
my $trainOut = "";
my $testOut = "";
my $namesOut = "";
my $normalizationFactorsOut = "";
my $matlabTrainOut = "trainMat.forMatlab";
my $matlabTestOut = "testMat.forMatlab";

GetOptions ("trainMat=s" => \$trainMat, # should be ../results/trainMat
			"testMat=s" => \$testMat,
			"trainOut=s" => \$trainOut,
			"testOut=s" => \$testOut,
			"namesOut=s" => \$namesOut,
			"normalizationFactorsOut=s" => \$normalizationFactorsOut,
			"matlabTrainOut=s" => \$matlabTrainOut,
			"matlabTestOut=s" => \$matlabTestOut);
			
if($trainMat eq "" || $testMat eq "" || $trainOut eq "" || $testOut eq "" || $namesOut eq "" ){
	die("Usage: normalizeSampleData.pl \t[-trainMat \t\t\ttrainingMatrix]\n". 
		"\t\t\t\t[-testMat \t\t\ttestMatrix] \n".
		"\t\t\t\t[-trainOut \t\t\tnormalizedTrainingMatrix] \n".
		"\t\t\t\t[-testOut \t\t\tnormalizedTestMatrix] \n".
		"\t\t\t\t[-namesOut \t\t\tfeatureNames] \n".
		"\t\t\t\t[-normalizationFactorsOut \tnormalizationRanges] \n".
		"\t\t\t\t[-matlabTrainOut \t\tnormalizedTrainMatrixForMatlab] \n". 
		"\t\t\t\t[-matlabTestOut \t\tnormalizedTestMatrixForMatlab] \n");
}

#END##########################################################################################

my %featuresNames = ();
my $numFeatures = 0;
my %featureRanges = ();
my %featureMinimalValues = ();

normalizeDataFile($trainMat, $trainOut, $matlabTrainOut, "1");
normalizeDataFile($testMat, $testOut, $matlabTestOut, "0");

open(NAMES, ">$namesOut") or die $!;
my $finalStr = "";
foreach my $key(sort {$a <=> $b} keys %featuresNames){
	$finalStr .= "$key:".$featuresNames{$key}."\n";
}
print NAMES $finalStr."\n";
close(NAMES);

########################################################
sub normalizeDataFile{
	my ($inFile, $outFile, $matlabFile, $isTrain) = @_;
	
	open(IN, "<$inFile") or die $!;
	open(OUT, ">$outFile") or die $!;
	open(OUT_MT, ">$matlabFile") or die $!;

	my @finalFeatures;
	my @originalFeatures;
	my $label;

	foreach my $line (<IN>){
		chomp($line);
		
		if($line =~ m/^#/){
			print OUT "$line\n";
			if($isTrain){
				initFeatures($line, $inFile);
			}
			next;
		}
		
		my $infoStr = "#";
		my $data = $line;
		if($line =~ m/(.*) (#.*)/){
			$data = $1;
			$infoStr = $2;
		}
		
		@originalFeatures = split(/ /, $data);
		$label = $originalFeatures[0];
		
		@finalFeatures = @originalFeatures;
		
#		for(my $featureNum = 1; $featureNum < scalar @originalFeatures; $featureNum++){
#			my $featureName = $featuresNames{$featureNum};
#			my $inputValue = $originalFeatures[$featureNum];
#			
#			if(
#	# 		$featureName eq "numExactFragmentsPerResidue" ||
#	# 		$featureName eq "numApproxFragmentsPerResidue" ||
#	# 		$featureName eq "numExactAtomsPerResidue" ||
#	# 		$featureName eq "numApproxAtomsPerResidue" ||
#			$featureName eq "numExactFragmentsPerResidue_relative" ||
#			$featureName eq "numApproxFragmentsPerResidue_relative" ||
#			$featureName eq "numExactAtomsPerResidue_relative" 
##			$featureName eq "numApproxAtomsPerResidue_relative" ||
##			$featureName eq "relativeConservationPerResidue" ||
##			$featureName eq "holesValuePerResidue"
#			){
#				$finalFeatures[$featureNum] = getNormalized($featureNum, $inputValue);
#			}
##			elsif($featureName eq "conservationPerResidue"){
##				$finalFeatures[$featureNum] = getNormalizedConservation($inputValue);
### 				$finalFeatures[$featureNum] = 0;
### 				if( $inputValue >= 6 ){
### 					$finalFeatures[$featureNum] = 1;
### 				}
##			}
##			elsif($featureName eq "residuePocketNumber"){
##				$finalFeatures[$featureNum] = getNormalizedPocketRank($inputValue);
##			}
##			elsif($featureName eq "AA_NUM"){
##				$finalFeatures[$featureNum] = ($inputValue-1)/21;
##			}
##			elsif($featureName eq "residueMoreConservedThanAvg"){
##				$finalFeatures[$featureNum] = ($inputValue+1)/2;
##			}
##			
##			if($finalFeatures[$featureNum] eq ""){
##				die("ERROR!!\nLINE:$line\nFeature Name($featureNum):$featureName\n".
##				"Input Value: '$inputValue'\n");
##			}
#			
#	# 		# Binary values
#	# 		"residueInPocket"
#	# 		"AA_HYDROPHOBIC"
#	# 		"AA_POLAR"
#	# 		"AA_AROMATIC"
#	# 		"AA_ALIPHATIC"
#	# 		"AA_HBONDING"
#	
#		}
		my @onlyFeatures = @finalFeatures[1 .. $#finalFeatures];
		numberArray(\@onlyFeatures);
		my $featuresStr = join(' ', @onlyFeatures);
		print OUT "$label $featuresStr $infoStr\n";
		
		$featuresStr = join(' ', @finalFeatures);
		print OUT_MT "$featuresStr\n";
	}
	
	close(OUT);
	close(OUT_MT);
	close(IN);
}

sub initFeatures{
	my ($header, $inputFile) = @_;
	my @parts = split(/ /, $header);
	for(my $i=1; $i < scalar @parts; $i++){
		$parts[$i] =~ s/.*://;
		$featuresNames{$i} = $parts[$i];
	}
	
	$numFeatures = scalar keys %featuresNames;
	
	for(my $i = 0; $i < $numFeatures; ++$i){
		my $featureNum = $i+1;
	
		SetFeatureRange($featureNum, $inputFile);
	}
}

sub SetFeatureRange{
	my($featureNum, $inputFile) = @_;

	my $cmd = "grep -v \"^#\" $inputFile | cut -d\" \" -f".($featureNum+1);
	chomp(my $valuesStr = `$cmd`);
	my @values = split(/\n/, $valuesStr);
	@values = sort {$a <=> $b} @values;
	my $range = $values[$#values] - $values[0];
	
	$featureMinimalValues{$featureNum} = $values[0];
	$featureRanges{$featureNum} = $range;
	
	#print "num $featureNum, range $range, minimum (".$values[0].")\n";
}

# scales values to the range [0..1]
sub getNormalized{
	my ($featureNum, $value) = @_;
	my $newValue = ($value - $featureMinimalValues{$featureNum}) / $featureRanges{$featureNum};
	
	if($newValue < 0){
		$newValue = 0;
	}
	elsif($newValue > 1){
		$newValue = 1;
	}
	return $newValue;
}

sub getNormalizedConservation{
	my ($value) = @_;
	my $newValue;
	
	if($value < 0){
		$newValue = 0;
	}
	elsif($value >= 0 && $value <= 2){
		$newValue = 1;
	}
	elsif($value >= 3 && $value <= 6){
		$newValue = 2;
	}
	else{
		$newValue = 3;
	}
	
	return ($newValue / 3);
}

sub getNormalizedPocketRank{
	my ($value) = @_;
	my $newValue;
	
	if($value == 1){
		$newValue = 1;
	}
	elsif($value == 2 || $value == 3){
		$newValue = 2;
	}
	elsif($value == 0){
		$newValue = 4;
	}
	else{
		$newValue = 3;
	}
	
	return ( ($newValue-1) / 3);
}

sub numberArray{
	my ($array) = @_;
	
	for(my $i = 0; $i < scalar @$array; $i++){
		$$array[$i] = ($i+1).":".$$array[$i];
	}
}