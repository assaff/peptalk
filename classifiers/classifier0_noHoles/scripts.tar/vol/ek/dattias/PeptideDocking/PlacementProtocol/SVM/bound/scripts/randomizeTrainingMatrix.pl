#!/usr/bin/perl
# author: dattias
# randomizeTrainingMatrix.pl

use strict;

my $trainingMat = $ARGV[0];
my $randomMat = $ARGV[1];

chomp(my @positiveExamples = `cat $trainingMat | egrep \"^\\+1\"`);
chomp(my @negativeExamples = `cat $trainingMat | egrep \"^\\-1\"`);

my $numPositives = scalar @positiveExamples;
my $numNegatives = scalar @negativeExamples;

if($numPositives > $numNegatives){
	die("More positives than negatives... This is odd.\n");
}
print "$numPositives positives Vs. $numNegatives negatives\n";

open(MAT, ">$randomMat") or die $!;

my $positiveLinesStr = join("\n", @positiveExamples);
print MAT "$positiveLinesStr\n";

#print "Random negative examples: ";
for(my $i = 0; $i < $numPositives; $i++){
	my $randInt = int(rand($numNegatives));
	#print "$randInt ";
	print MAT $negativeExamples[$randInt]."\n";
}
#print "\n";

close(MAT);

