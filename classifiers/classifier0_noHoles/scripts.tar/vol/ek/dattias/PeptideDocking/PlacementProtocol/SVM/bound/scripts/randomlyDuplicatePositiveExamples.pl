#!/usr/bin/perl
# author: dattias
# randomizeTrainingMatrix.pl

# Create random training matrix with duplicate positive examples

use strict;

my $trainingMat = $ARGV[0];
my $randomMat = $ARGV[1];
#my $trainingMat = "trainMat.perRes.binary.svmlight";
#my $randomMat = "randomTrainMat.perRes.binary.svmlight";

chomp(my @positiveExamples = `cat $trainingMat | egrep \"^\\+1\"`);
chomp(my @negativeExamples = `cat $trainingMat | egrep \"^\\-1\"`);

my $numPositives = scalar @positiveExamples;
my $numNegatives = scalar @negativeExamples;

if($numPositives > $numNegatives){
	die("More positives than negatives... This is odd.\n");
}
print "$numPositives positives Vs. $numNegatives negatives\n";

my $numPositivesToDup = $numNegatives-$numPositives;

my $negativeSampleIndex = $numPositives;
my @newLearningExamples = (@positiveExamples, @negativeExamples[0 .. $negativeSampleIndex-1]);

#print "Random positive examples: ";
for(my $i = 0; $i < $numPositivesToDup; $i++){
	
	@newLearningExamples = (@newLearningExamples, $negativeExamples[$negativeSampleIndex]);
	my $randInt = int(rand($numPositives));
	#print "$randInt ";
	#print MAT $negativeExamples[$randInt]."\n";
	@newLearningExamples = (@newLearningExamples, $positiveExamples[$randInt]);
	print "going ($negativeSampleIndex) ... ";
	$negativeSampleIndex++;
}
print "\n";

open(MAT, ">$randomMat") or die $!;
my $newLearningExamplesStr = join("\n", @newLearningExamples);
print MAT "$newLearningExamplesStr\n";
close(MAT);

