#!/usr/bin/perl
# author: dattias
# removeNoisyFeatures.pl

use strict;

my $inputFile = $ARGV[0];
my $outputFile = $ARGV[1];

my $inputFile_names = $ARGV[2];
my $outputFile_names = $ARGV[3];

print "Data input file: $inputFile\nData output file: $outputFile\nNames input file: $inputFile_names\nNames output file: $outputFile_names\n";

my %noisyFeatures = ();

foreach my $featureToRemove(@ARGV){
	$noisyFeatures{$featureToRemove} = 1;
}

my @noisyFeatureList = keys %noisyFeatures;
print "Noisy features: @noisyFeatureList\n";

# my %noisyFeatures = ( 
# 	19 => 1, 	26 => 1,	27 => 1,	4 => 1,	47 => 1,	48 => 1,	49 => 1,	50 => 1,	5 => 1,	51 => 1,	52 => 1,	53 => 1,
# 	60 => 1,	61 => 1,	62 => 1,	63 => 1,	64 => 1,	65 => 1,	66 => 1,	67 => 1,	68 => 1,	69 => 1,	70 => 1,
# 	7 => 1,	71 => 1,	72 => 1,	73 => 1,	74 => 1,	75 => 1,	76 => 1,	77 => 1
# # 	31 => 1,	78 => 1, 	82 => 1, 	56 => 1, 	40 => 1, 	2 => 1,	41 => 1,  	6 => 1,  	80 => 1,  	28 => 1,  	36 => 1,  	17 => 1,  
# # 	59 => 1,  	30 => 1,  	37 => 1,    	35 => 1,	33 => 1,	1 => 1,	54 => 1,	58 => 1,	3 => 1,	16 => 1,	4 => 1,	26 => 1,
# # 	27 => 1,	5 => 1,	47 => 1,	48 => 1,	49 => 1,	50 => 1,	51 => 1,	52 => 1,	53 => 1,	7 => 1,
# );

open(IN, "<$inputFile") or die $!;
open(OUT, ">$outputFile") or die $!;
open(IN_NAMES, "<$inputFile_names") or die $!;
open(OUT_NAMES, ">$outputFile_names") or die $!;

my @finalFeatures;
foreach my $line (<IN>){
	chomp($line);
	@finalFeatures = ();
	
	my @features = split(/ /, $line);
	my $label = shift @features;
	
	for(my $i = 0; $i < scalar @features; ++$i){
		if(! exists($noisyFeatures{$i+1}) ){
			$features[$i] =~ s/.*:(.*)/$1/;
			@finalFeatures = (@finalFeatures, $features[$i]);
		}
	}
	
	numberFeatures(\@finalFeatures);
	my $featuresStr = join(' ', @finalFeatures);
	print OUT "$label $featuresStr\n";
}

my @finalNames = ();
foreach my $line (<IN_NAMES>){
	chomp($line);
	if($line =~ m/(.*):(.*)/){
		my $num = $1;
		my $name = $2;
		if(! exists($noisyFeatures{$num}) ){
			@finalNames = (@finalNames, $name);
		}
	}
}
numberFeatures(\@finalNames);
my $namesStr = join("\n", @finalNames);
print OUT_NAMES $namesStr;

close(OUT);
close(IN);
close(OUT_NAMES);
close(IN_NAMES);

########################################################
sub numberFeatures{
	my ($featuresList) = @_;
	
	for(my $i = 0; $i < scalar @$featuresList; $i++){
		$$featuresList[$i] = ($i+1).":".$$featuresList[$i];
	}
}
