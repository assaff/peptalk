pathdef;

display PDBID
cov = load('PDBID.mat.cov');
hb = load('PDBID.mat.hb'); 

%interface = load('PDBID.mat.interfaceRes'); 
%chainClass_temp = importdata('PDBID.mat.chainClass');
%chainClass = char(chainClass_temp(:));
%clear chainClass_temp

%mainChainInterface = (interface(:) == 1) & (chainClass(:) == 'A');

%[stats_PDBID, statsWPeptide_PDBID] = motifStatistics(hb, cov, chainClass);

bonds_total = cov + hb;
%[simpleStats_PDBID, simpleStatsWPeptide_PDBID] = simpleMotifStatistics(bonds_total, chainClass);
[minimalStats_PDBID] = minimalMotifStatistics(bonds_total);

%review = [mainChainInterface minimalStats_PDBID];

clear cov hb

save PDBID_data;
display DONE_DATA

temp = full(minimalStats_PDBID);
fid = fopen('minimalMotifs_PDBID.txt', 'w');
for i=1:size(temp,1)
    for j=1:size(temp,2)
        fprintf(fid, '%d ', temp(i,j));
    end
    fprintf(fid, '\n');
end
fclose(fid);

display DONE_SAVE

display DONE