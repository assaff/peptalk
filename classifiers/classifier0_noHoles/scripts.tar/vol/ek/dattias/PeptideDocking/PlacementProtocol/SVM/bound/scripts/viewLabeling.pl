#!/usr/bin/perl
# author: dattias
# viewLabeling.pl

use strict;

my $pdb = shift;

my $dataFile = "../scripts/train.log";
my $rasscript = "$pdb.labeling.rasscript";

chomp(my @tmpLines = `cat $dataFile | grep -A10 \"^PDB $pdb\"`);
my @lines;
foreach my $line(@tmpLines){
	last if($line =~ m/^PDB (....)/ && $pdb ne $1);
	@lines = (@lines, $line);
}

my $burriedStr = getDataStr("burriedResidues", \@lines);
my $contactingStr = getDataStr("contactingResidues", \@lines);

open(SCRIPT, ">$rasscript") or die $!;
#print SCRIPT "load /vol/ek/dattias/PeptideDocking/PlacementProtocol/bound/boundSet/$pdb.pdb\n";
print SCRIPT "load C:/Users/Dana/Documents/HUJI/lab/boundSet/$pdb.pdb\n";
print SCRIPT "color chain\n";
print SCRIPT "select *:A\n";
print SCRIPT "spacefill\n";
print SCRIPT "select *:B\n";
print SCRIPT "wireframe 100\n";
if($burriedStr ne ""){
	print SCRIPT "select *:A and ($burriedStr)\n";
	print SCRIPT "color magenta\n";
}
if($contactingStr ne ""){
	print SCRIPT "select *:A and ($contactingStr)\n";
	print SCRIPT "color green\n";
}
close(SCRIPT);

###################################################3
sub getDataStr{
	my ($dataType, $allData) = @_;
	
	my @tmp = grep(/$dataType/, @$allData);
	if(scalar @tmp != 1){
		die("Data type $dataType not found for $pdb\n");
	}
	
	my @parts = split(/ /, $tmp[0]);
	shift(@parts);
	my $dataStr = join(" or ", @parts);
	return $dataStr;
}

