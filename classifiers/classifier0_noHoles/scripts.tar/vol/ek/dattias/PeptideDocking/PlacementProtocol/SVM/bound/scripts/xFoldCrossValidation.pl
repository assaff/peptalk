#!/usr/bin/perl
# author: dattias
# xFoldCrossValidation.pl

use strict;
use POSIX;

my $trainingMat = $ARGV[0];
my $crossValidationDir = $ARGV[1];
my $outFilePrefix = $ARGV[2];
my $learnParametersStr = $ARGV[3];

my $fold = 10;

## Create different sets
#########################
if(! -e $crossValidationDir){
	mkdir $crossValidationDir;
}

chomp(my @positiveExamples = `cat $trainingMat | egrep \"^\\+1\"`);
chomp(my @negativeExamples = `cat $trainingMat | egrep \"^\\-1\"`);

my $numPositives = scalar @positiveExamples;
my $numNegatives = scalar @negativeExamples;

if($numPositives > $numNegatives){
	die("More positives than negatives... This is odd.\n");
}
print "$numPositives positives Vs. $numNegatives negatives\n";

my %sets = ();

my $positivesPerSet = floor($numPositives / $fold);
my $negativesPerSet = floor($numNegatives / $fold);

print "Per set: $positivesPerSet positives Vs. $negativesPerSet negatives\n";

my $currPositiveIndex = 0;
my $currNegativeIndex = 0;

my $i = 0;
for( ; $i < $fold; $i++){
	$sets{$i} = "";
	
	for(my $j = 0; $j < $positivesPerSet; $j++){
		$sets{$i} .= $positiveExamples[$currPositiveIndex] + "\n";
		$currPositiveIndex++;
	}
	for(my $j = 0; $j < $negativesPerSet; $j++){
		$sets{$i} .= $negativeExamples[$currNegativeIndex] + "\n";
		$currNegativeIndex++;
	}
	
	if($i != $fold -1){
		open(OUT, ">$crossValidationDir/$outFilePrefix.".($i+1) ) or die $!;
		print OUT $sets{$i};
		close OUT;
	}
}

while ($currPositiveIndex < $numPositives){
	$sets{$i} .= $positiveExamples[$currPositiveIndex] + "\n";
	$currPositiveIndex++;
}

while ($currNegativeIndex < $numNegatives){
	$sets{$i} .= $negativeExamples[$currNegativeIndex] + "\n";
	$currNegativeIndex++;
}
open(OUT, ">$crossValidationDir/$outFilePrefix.".($i+1) ) or die $!;
print OUT $sets{$i};
close OUT;

## Calculate data matrices
###########################

# Number really positive / all marked as positive
my %precision;
# Num marked as positive / all positives in data set
my %recall;
# Correct classification
my %accuracy;
# Number of Support Vectors
my %numSV;

$i = 0;
my $learnCmd;
my $classifyCmd;
my $currSetFileName;
my $currSetModelFileName;
my $currSetLogFileName;
my $otherFilesStr;
my $othersFileName;
my $classifyOutputFileName;
my $currClassifyLogFileName;
my ($curr_accuracy, $curr_precision, $curr_recall);
for( ; $i < $fold; $i++){
	# Learn by 1
	$currSetFileName = "$crossValidationDir/$outFilePrefix.".($i+1);
	$currSetModelFileName = "$crossValidationDir/svmModel.".($i+1);
	$currSetLogFileName = "$crossValidationDir/svmLearn.log.".($i+1);
	$learnCmd = "/vol/ek/share/bin/svm_learn $learnParametersStr $currSetFileName $currSetModelFileName >! $currSetLogFileName";
	`$learnCmd`;
	# Classify by rest
	$otherFilesStr = "";
	for(my $j = 0; $j < $fold; $j++){
		if($j != $i){
			$otherFilesStr .= "$crossValidationDir/$outFilePrefix.".($j+1)." ";
		}
	}
	$othersFileName = "$crossValidationDir/others.".($i+1);
	$classifyOutputFileName = "$crossValidationDir/output.".($i+1);
	$currClassifyLogFileName = "$crossValidationDir/svmClassify.log.".($i+1);
	`cat $otherFilesStr > $othersFileName`;
	$classifyCmd = "/vol/ek/share/bin/svm_classify $othersFileName $currSetModelFileName $classifyOutputFileName >! $currClassifyLogFileName";
	`$classifyCmd`;
	# Update parameters
	my $numSVs = `grep " # number of support vectors" $currSetModelFileName | cut -d"#" -f1`;
	trim(\$numSVs);
	$numSV{$i} = $numSVs;
	($curr_accuracy, $curr_precision, $curr_recall) = goOverResults($othersFileName, $classifyOutputFileName);
	$accuracy{$i} = $curr_accuracy;
	$precision{$i} = $curr_precision;
	$recall{$i} = $curr_recall;
}

## Calculate final values
##########################

########################################################################
sub trim{
	my ($str) = @_;
	$$str =~ s/\s//g;
}

sub goOverResults{
	my ($input, $output) = @_;
	
	my $classifiedAsPositive;
	my $truePositives;
	my $positiveOvservationsInDataset;
	my $accuratePredictions;
	my $datasetSize;
	
	open(IN, "<$input") or die $!;
	chomp(my @observations = grep(/^[^#]/, <IN>));
	close(IN);
	
	open(OUT, "<$output") or die $!;
	chomp(my @decisions = <OUT>);
	close(OUT);
	
	if(scalar @observations != scalar @decisions){
		die("Error: size of observations (".(scalar @observations).") is not equal to size of decisions (".(scalar @decisions).")");
	}
	
	$datasetSize = scalar @observations;
	#$positiveOvservationsInDataset = grep(/^\+1/, @observations);
	
	foreach my $example(@observations){
		$example =~ //
	}

	my $currObservation;
	for (my $i = 0; $i < $datasetSize; $i++){
		$currObservation = $observations[$i];
		$currObservation =~ s/^(..).*/$1/;
		
		if($currObservation > 0){
			$positiveOvservationsInDataset++;
		}
		
		if($decisions[$i] > 0){
			# Classified as positive
			$classifiedAsPositive++;
			if($currObservation > 0){
				$truePositives++;
				$accuratePredictions++;
			}
		}
		else{
			# Classified as negative
			if($currObservation < 0){
				$accuratePredictions++;
			}
		}
	}
	
	my $accuracy = ($accuratePredictions*100)/$datasetSize;
	my $precision = ($truePositives*100)/$classifiedAsPositive;
	my $recall = ($truePositives*100)/$positiveOvservationsInDataset;
	return ($accuracy, $precision, $recall);
}



